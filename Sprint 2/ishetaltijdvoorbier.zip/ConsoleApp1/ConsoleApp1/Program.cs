﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            String dag;
            dag = DateTime.Now.DayOfWeek.ToString();

            String hourMinute;
            hourMinute = DateTime.Now.ToString("HH:mm");
            Console.WriteLine("Is het altijd voor bier?");
            Console.ReadLine();

            Console.WriteLine("Het is vandaag " + (DateTime.Now.DayOfWeek) + " " +(hourMinute));
            Console.ReadLine();

            DateTime date1 = DateTime.Now;

            if (dag == "Saturday" || dag == "Sunday")
            {
                if (date1.Hour >= 0 && date1.Hour <= 23)
                {
                    Console.WriteLine("Ja! het is tijd voor bier!");
                    Console.ReadLine();
                }
            }
            else
            {
                if (date1.Hour >= 0 && date1.Hour <= 16)
                {
                    Console.WriteLine("Helaas, het is " + (hourMinute) +". Het is nog te vroeg :(");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Ja! het is tijd voor bier!");
                }
                Console.ReadKey();
            }

        }
    }
}